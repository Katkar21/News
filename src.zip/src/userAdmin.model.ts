export class UserAdmin{

    emailId='';
	securityQuestion='';
	securityAnswer='';
	userPassword='';
	
}