
    export class Article{


        title='';
        content='';
        description=''
        author=''
        url=''
        urlToImage=''
    
    
    }