export class Fav{
url:String='';
urlToImage:String='';
title:String='';
description:String='';
author:String='';
userName:String='';
  

}